
Tech Crunch with Core Data

1. First I designed simple UI with two tab bar 
2. Home tab bar, showed some data from the sample Api
3. This list also have two features
      * swipe to delete the data
      * And select any cell that data to be saved in core data
4. That Saved tab bar showed user saved data

MVVM:
  Model-View-ViewModel
  It is powerfull design pattern
  Its reduce the code Complexity
  And Increases code Re-Usability
  

NOTE : This is sample app.i also know swiftUI with latest features example swiftdata, Dynamic Island, Widgets, App Intens. client requirements based i set some extra features.this features behaves, user-friendly and easy to use the app function without opening the app
